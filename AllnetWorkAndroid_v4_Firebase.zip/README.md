# Allnet-work Android

Aplikasi Android berita yang mengambil posting langsung dari Blogger Allnet-work.

## Sumber data
- Website: https://www.allnet-work.web.id
- Feed: https://www.allnet-work.web.id/feeds/posts/default?alt=json&max-results=30

Aplikasi mengambil:
- judul
- tanggal
- penulis
- label/kategori
- URL artikel
- gambar pertama dari isi posting

Halaman detail membuka URL artikel asli di WebView, sehingga gambar dan isi artikel mengikuti posting di blog.

## Cara membuka
1. Install Android Studio.
2. Open folder `AllnetWorkAndroid`.
3. Tunggu Gradle Sync.
4. Jalankan pada emulator/perangkat Android.
5. Untuk APK: Build > Build APK(s).

## Catatan
Jika Blogger mematikan JSON feed atau template mengubah struktur feed, bagian `fetchPosts()` perlu disesuaikan.


## Versi 2
- Kategori cepat berbentuk chip di beranda.
- Simpan artikel selama aplikasi aktif.
- Bagikan artikel menggunakan menu Android.
- Detail tetap membuka URL artikel asli agar konten dan gambar mengikuti posting blog.
- Struktur beranda mengikuti elemen yang terlihat di allnet-work.web.id: Beranda, kategori, artikel terbaru, dan navigasi website.


## Firebase
Firebase Analytics and Firebase Cloud Messaging are configured using the supplied `google-services.json`. The Firebase Android package is `id.web.allnetwork.news`.
