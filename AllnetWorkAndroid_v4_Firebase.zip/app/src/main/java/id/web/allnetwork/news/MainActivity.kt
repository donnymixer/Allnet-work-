package id.web.allnetwork.news

import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color as ComposeColor
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import coil.compose.AsyncImage
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.jsoup.Jsoup
import org.json.JSONObject
import okhttp3.OkHttpClient
import okhttp3.Request
import java.text.SimpleDateFormat
import java.util.*
import java.util.concurrent.TimeUnit

private const val BLOG_URL = "https://www.allnet-work.web.id"
private const val FEED_URL = "$BLOG_URL/feeds/posts/default?alt=json&max-results=30"

data class Post(
    val title: String,
    val url: String,
    val published: String,
    val author: String,
    val labels: List<String>,
    val html: String,
    val imageUrl: String?
) {
    val summary: String
        get() = Jsoup.parse(html).text().replace(Regex("\\s+"), " ").trim()
            .let { if (it.length > 150) it.take(150) + "…" else it }
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { AllnetWorkApp() }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AllnetWorkApp() {
    val context = LocalContext.current
    var posts by remember { mutableStateOf<List<Post>>(emptyList()) }
    var loading by remember { mutableStateOf(true) }
    var error by remember { mutableStateOf<String?>(null) }
    var selectedPost by remember { mutableStateOf<Post?>(null) }
    var category by remember { mutableStateOf("Semua") }
    var infoScreen by remember { mutableStateOf<String?>(null) }
    var savedUrls by remember { mutableStateOf(setOf<String>()) }
    var search by remember { mutableStateOf("") }
    var drawerOpen by remember { mutableStateOf(false) }
    var reloadKey by remember { mutableIntStateOf(0) }
    val drawerState = rememberDrawerState(DrawerValue.Closed)

    LaunchedEffect(drawerOpen) {
        if (drawerOpen) drawerState.open() else drawerState.close()
    }

    suspend fun loadPosts() {
        loading = true
        error = null
        try {
            posts = fetchPosts()
        } catch (e: Exception) {
            error = "Berita belum dapat dimuat. Periksa koneksi internet."
        } finally {
            loading = false
        }
    }

    LaunchedEffect(reloadKey) { loadPosts() }

    val categories = remember(posts) {
        listOf("Semua") + posts.flatMap { it.labels }
            .map { it.trim() }
            .filter { it.isNotBlank() }
            .distinct()
            .take(15)
    }

    val filtered = remember(posts, category, search) {
        posts.filter { p ->
            val catOk = category == "Semua" || p.labels.any { it.equals(category, true) }
            val q = search.trim()
            val searchOk = q.isBlank() || p.title.contains(q, true) || p.summary.contains(q, true)
            catOk && searchOk
        }
    }

    ModalNavigationDrawer(
        drawerState = drawerState,
        drawerContent = {
            ModalDrawerSheet {
                Spacer(Modifier.height(20.dp))
                Text("allnet-work", fontSize = 26.sp, fontWeight = FontWeight.Bold,
                    modifier = Modifier.padding(horizontal = 24.dp))
                Text("JARINGAN INFORMASI UNTUK SEMUA", fontSize = 10.sp,
                    modifier = Modifier.padding(horizontal = 24.dp, vertical = 2.dp))
                Spacer(Modifier.height(18.dp))
                NavigationDrawerItem(
                    label = { Text("Beranda") },
                    selected = category == "Semua",
                    onClick = { category = "Semua"; drawerOpen = false },
                    icon = { Icon(Icons.Default.Home, null) }
                )
                Text("Kategori", fontWeight = FontWeight.Bold,
                    modifier = Modifier.padding(24.dp, 18.dp, 24.dp, 6.dp))
                categories.drop(1).forEach { c ->
                    NavigationDrawerItem(
                        label = { Text(c) },
                        selected = category == c,
                        onClick = { category = c; drawerOpen = false },
                        icon = { Icon(Icons.Default.Label, null) }
                    )
                }
                Spacer(Modifier.weight(1f))
                NavigationDrawerItem(
                    label = { Text("Tentang Puskom") },
                    selected = false,
                    onClick = { infoScreen = "Tentang Puskom"; drawerOpen = false },
                    icon = { Icon(Icons.Default.Info, null) }
                )
                NavigationDrawerItem(
                    label = { Text("Kebijakan Privasi") },
                    selected = false,
                    onClick = { infoScreen = "Kebijakan Privasi"; drawerOpen = false },
                    icon = { Icon(Icons.Default.Lock, null) }
                )
                NavigationDrawerItem(
                    label = { Text("Kontak Redaksi") },
                    selected = false,
                    onClick = { infoScreen = "Kontak Redaksi"; drawerOpen = false },
                    icon = { Icon(Icons.Default.Email, null) }
                )
                NavigationDrawerItem(
                    label = { Text("Buka Website") },
                    selected = false,
                    onClick = { openUrl(context, BLOG_URL); drawerOpen = false },
                    icon = { Icon(Icons.Default.Language, null) }
                )
                Spacer(Modifier.height(12.dp))
            }
        }
    ) {
        if (selectedPost == null && infoScreen == null) {
            Scaffold(
                topBar = {
                    TopAppBar(
                        title = {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text("an", color = ComposeColor(0xFF008EE8), fontWeight = FontWeight.ExtraBold)
                                Text(" allnet-work", color = ComposeColor(0xFFE91E63), fontWeight = FontWeight.ExtraBold)
                            }
                        },
                        navigationIcon = {
                            IconButton(onClick = { drawerOpen = true }) {
                                Icon(Icons.Default.Menu, "Menu")
                            }
                        },
                        actions = {
                            IconButton(onClick = { /* search field below */ }) {
                                Icon(Icons.Default.Search, "Cari")
                            }
                        }
                    )
                },
                bottomBar = {
                    NavigationBar {
                        NavigationBarItem(true, { category = "Semua" }, Icons.Default.Home, { Text("Beranda") })
                        NavigationBarItem(false, { drawerOpen = true }, Icons.Default.Category, { Text("Kategori") })
                        NavigationBarItem(false, { search = if (search.isBlank()) " " else "" }, Icons.Default.Search, { Text("Cari") })
                        NavigationBarItem(false, { openUrl(context, BLOG_URL) }, Icons.Default.Language, { Text("Website") })
                    }
                }
            ) { pad ->
                Column(Modifier.padding(pad)) {
                    OutlinedTextField(
                        value = search.trim(),
                        onValueChange = { search = it },
                        modifier = Modifier.fillMaxWidth().padding(12.dp),
                        placeholder = { Text("Cari berita Allnet-work…") },
                        leadingIcon = { Icon(Icons.Default.Search, null) },
                        singleLine = true
                    )

                    if (categories.size > 1) {
                        androidx.compose.foundation.lazy.LazyRow(
                            contentPadding = PaddingValues(horizontal = 12.dp),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            items(categories.take(8)) { c ->
                                FilterChip(
                                    selected = category == c,
                                    onClick = { category = c },
                                    label = { Text(c) }
                                )
                            }
                        }
                        Spacer(Modifier.height(6.dp))
                    }

                    if (loading) {
                        LinearProgressIndicator(Modifier.fillMaxWidth())
                    } else if (error != null) {
                        ErrorBox(error!!, onRetry = { reloadKey++ })
                    }

                    if (!loading && filtered.isEmpty()) {
                        Text("Belum ada artikel yang cocok.", modifier = Modifier.padding(24.dp))
                    }

                    LazyColumn(
                        contentPadding = PaddingValues(12.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        if (filtered.isNotEmpty()) {
                            item {
                                HeroPost(filtered.first()) { selectedPost = it }
                                Text("Berita Terbaru", fontSize = 22.sp, fontWeight = FontWeight.Bold,
                                    modifier = Modifier.padding(top = 18.dp, bottom = 4.dp))
                            }
                            items(filtered.drop(1)) { post ->
                                PostCard(post) { selectedPost = it }
                            }
                        }
                    }
                }
            }
        } else if (infoScreen != null) {
            InfoScreen(title = infoScreen!!, onBack = { infoScreen = null })
        } else {
            ArticleScreen(
                selectedPost!!,
                isSaved = savedUrls.contains(selectedPost!!.url),
                onToggleSave = {
                    savedUrls = if (savedUrls.contains(selectedPost!!.url))
                        savedUrls - selectedPost!!.url else savedUrls + selectedPost!!.url
                },
                onBack = { selectedPost = null }
            )
        }
    }
}

@Composable
fun HeroPost(post: Post, onClick: (Post) -> Unit) {
    Card(
        modifier = Modifier.fillMaxWidth().clickable { onClick(post) },
        shape = RoundedCornerShape(18.dp)
    ) {
        Column {
            post.imageUrl?.let {
                AsyncImage(it, null, Modifier.fillMaxWidth().height(230.dp), contentScale = ContentScale.Crop)
            }
            Column(Modifier.padding(16.dp)) {
                Text(post.labels.firstOrNull() ?: "BERITA", color = ComposeColor(0xFF0B63CE),
                    fontWeight = FontWeight.Bold, fontSize = 12.sp)
                Text(post.title, fontSize = 22.sp, fontWeight = FontWeight.ExtraBold)
                Text(formatDate(post.published) + " • " + post.author,
                    fontSize = 12.sp, color = ComposeColor.Gray, modifier = Modifier.padding(top = 8.dp))
            }
        }
    }
}

@Composable
fun PostCard(post: Post, onClick: (Post) -> Unit) {
    Card(
        modifier = Modifier.fillMaxWidth().clickable { onClick(post) },
        shape = RoundedCornerShape(14.dp)
    ) {
        Row(Modifier.padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
            post.imageUrl?.let {
                AsyncImage(it, null, Modifier.size(105.dp, 78.dp).clip(RoundedCornerShape(10.dp)),
                    contentScale = ContentScale.Crop)
            }
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text(post.title, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                Text(formatDate(post.published), fontSize = 11.sp, color = ComposeColor.Gray,
                    modifier = Modifier.padding(top = 6.dp))
            }
        }
    }
}


@Composable
fun InfoScreen(title: String, onBack: () -> Unit) {
    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(title) },
                navigationIcon = {
                    IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, "Kembali") }
                }
            )
        }
    ) { pad ->
        val body = when (title) {
            "Tentang Puskom" -> """
                ALLNET-WORK

                Penerbit / Sumber: Puskom
                Redaksi: Tim Allnet-Work
                Website: https://www.allnet-work.web.id

                Allnet-work adalah aplikasi berita yang menyajikan artikel dari situs resmi Allnet-work. Artikel ditulis oleh redaksi sendiri.

                Alamat Redaksi:
                Sawahjoho, Warungasem, BTG
            """.trimIndent()
            "Kontak Redaksi" -> """
                KONTAK REDAKSI

                Email aplikasi:
                puskome@gmail.com

                Email redaksi:
                donnymixer@gmail.com

                Penerbit:
                Puskom
            """.trimIndent()
            else -> """
                KEBIJAKAN PRIVASI ALLNET-WORK

                Terakhir diperbarui: 3 Oktober 2026

                Aplikasi Allnet-work mengambil artikel publik dari situs https://www.allnet-work.web.id untuk ditampilkan kepada pengguna.

                Data dan layanan:
                • Aplikasi dapat menggunakan notifikasi untuk memberi informasi tentang artikel baru.
                • Aplikasi dapat menggunakan analytics untuk memahami penggunaan aplikasi dan meningkatkan layanan.
                • Aplikasi dapat menampilkan iklan melalui Google AdMob.
                • Artikel yang disimpan sebagai favorit disimpan pada perangkat dan tidak dikirim ke server kami sebagai akun pribadi.

                Layanan pihak ketiga seperti Google Analytics/Firebase dan Google AdMob dapat memproses data teknis sesuai kebijakan privasi masing-masing. Pengguna dapat melihat kebijakan Google melalui situs resmi Google.

                Kontak privasi:
                puskome@gmail.com

                Pengelola:
                Puskom
            """.trimIndent()

        }
        Column(
            Modifier.fillMaxSize().padding(pad).padding(20.dp)
        ) {
            Text(body, fontSize = 15.sp, lineHeight = 23.sp)
        }
    }
}

@Composable
fun ArticleScreen(
    post: Post,
    isSaved: Boolean,
    onToggleSave: () -> Unit,
    onBack: () -> Unit
) {
    val context = LocalContext.current
    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Berita") },
                navigationIcon = {
                    IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, "Kembali") }
                },
                actions = {
                    IconButton(onClick = onToggleSave) {
                        Icon(
                            if (isSaved) Icons.Default.Bookmark else Icons.Default.BookmarkBorder,
                            contentDescription = if (isSaved) "Hapus simpanan" else "Simpan berita"
                        )
                    }
                    IconButton(onClick = {
                        val send = Intent(Intent.ACTION_SEND).apply {
                            type = "text/plain"
                            putExtra(Intent.EXTRA_SUBJECT, post.title)
                            putExtra(Intent.EXTRA_TEXT, "${post.title}\n${post.url}")
                        }
                        context.startActivity(Intent.createChooser(send, "Bagikan berita"))
                    }) {
                        Icon(Icons.Default.Share, "Bagikan")
                    }
                }
            )
        }
    ) { pad ->
        AndroidView(
            modifier = Modifier.fillMaxSize().padding(pad),
            factory = { ctx ->
                WebView(ctx).apply {
                    webViewClient = WebViewClient()
                    settings.javaScriptEnabled = true
                    settings.domStorageEnabled = true
                    settings.loadsImagesAutomatically = true
                    settings.mixedContentMode = WebSettings.MIXED_CONTENT_NEVER_ALLOW
                    loadUrl(post.url)
                }
            }
        )
    }
}

@Composable
fun ErrorBox(message: String, onRetry: () -> Unit) {
    Column(Modifier.fillMaxWidth().padding(16.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Text(message)
        Spacer(Modifier.height(8.dp))
        Button(onClick = onRetry) { Text("Coba lagi") }
    }
}

suspend fun fetchPosts(): List<Post> = withContext(Dispatchers.IO) {
    val client = OkHttpClient.Builder()
        .connectTimeout(20, TimeUnit.SECONDS)
        .readTimeout(30, TimeUnit.SECONDS)
        .build()
    val request = Request.Builder().url(FEED_URL).header("User-Agent", "Allnet-work Android App/1.0").build()
    client.newCall(request).execute().use { response ->
        if (!response.isSuccessful) error("HTTP ${response.code}")
        val json = JSONObject(response.body?.string() ?: error("Empty response"))
        val entries = json.getJSONObject("feed").optJSONArray("entry") ?: return@withContext emptyList()
        buildList {
            for (i in 0 until entries.length()) {
                val e = entries.getJSONObject(i)
                val title = e.optJSONObject("title")?.optString("\$t").orEmpty()
                val content = e.optJSONObject("content")?.optString("\$t")
                    ?: e.optJSONObject("summary")?.optString("\$t").orEmpty()
                val links = e.optJSONArray("link")
                var url = BLOG_URL
                if (links != null) {
                    for (j in 0 until links.length()) {
                        val l = links.getJSONObject(j)
                        if (l.optString("rel") == "alternate") {
                            url = l.optString("href", BLOG_URL)
                            break
                        }
                    }
                }
                val published = e.optJSONObject("published")?.optString("\$t")
                    ?: e.optJSONObject("updated")?.optString("\$t").orEmpty()
                val author = e.optJSONArray("author")?.optJSONObject(0)
                    ?.optJSONObject("name")?.optString("\$t") ?: "Puskom"
                val cats = mutableListOf<String>()
                e.optJSONArray("category")?.let { arr ->
                    for (j in 0 until arr.length()) cats += arr.getJSONObject(j).optString("term")
                }
                val img = Regex("""<img[^>]+src=['"]([^'"]+)['"]""", RegexOption.IGNORE_CASE)
                    .find(content)?.groupValues?.getOrNull(1)
                if (title.isNotBlank()) add(Post(title, url, published, author, cats, content, img))
            }
        }
    }
}

fun formatDate(value: String): String = try {
    val input = SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ssXXX", Locale.US)
    val d = input.parse(value) ?: return value.take(10)
    SimpleDateFormat("dd MMM yyyy", Locale("id", "ID")).format(d)
} catch (_: Exception) { value.take(10) }

fun openUrl(context: Context, url: String) {
    context.startActivity(Intent(Intent.ACTION_VIEW, android.net.Uri.parse(url)))
}
