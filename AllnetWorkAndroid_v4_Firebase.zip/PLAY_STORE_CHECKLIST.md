# Allnet-work - Play Store Preparation

## Identitas
- App: Allnet-work
- Developer: Puskom
- Publisher/source: Puskom
- Editorial team: Tim Allnet-Work
- App email: puskome@gmail.com
- Editorial email: donnymixer@gmail.com
- Editorial address: Sawahjoho, Warungasem, BTG
- Website: https://www.allnet-work.web.id

## Content
- Articles are written by the editorial team.
- App consumes the public Blogger JSON feed.
- Article detail links to the original article.
- Source/publisher information is exposed in the app.

## Services declared for implementation
- Push notifications: planned
- Analytics: planned
- AdMob: planned

## Release requirements still requiring Play Console work
1. Create/verify Play Console developer account.
2. Prepare final privacy-policy web URL.
3. Configure AdMob app/ad unit IDs.
4. Configure Firebase/Analytics and notification infrastructure if used.
5. Build signed Android App Bundle (.aab).
6. Complete store listing and content declarations.
7. Complete any required testing track for the developer account.
8. Submit for Google review.

This checklist does not guarantee approval; Google makes the final review decision.
