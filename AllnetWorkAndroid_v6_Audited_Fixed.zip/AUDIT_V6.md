# Audit V6

## Fixed
1. Java 17 and Kotlin JVM target 17 are aligned.
2. Firebase Messaging topic subscription `allnet_news` is initialized on app start.
3. Android 13+ notification permission is requested at runtime.
4. Notification small icon changed from the full-color launcher logo to a monochrome vector icon.
5. Notification tap opens `MainActivity`.
6. AndroidX Core dependency is declared explicitly.
7. `targetSdk = 36` and `compileSdk = 36` remain unchanged.
8. Existing Firebase `google-services.json` and application ID are preserved.

## Not claimed as complete
- Automatic blog-post detection and automatic FCM sending from a server are not implemented by the Android APK alone.
- AdMob is not enabled because official AdMob App ID/ad unit IDs were not provided.
- A signed Play Store AAB and Play Console declarations are still separate release steps.
