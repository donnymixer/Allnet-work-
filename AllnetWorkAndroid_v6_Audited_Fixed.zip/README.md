# Allnet-work Android

Aplikasi Android berita yang mengambil posting langsung dari Blogger Allnet-work.

## Sumber data
- Website: https://www.allnet-work.web.id
- Feed: https://www.allnet-work.web.id/feeds/posts/default?alt=json&max-results=30

Aplikasi mengambil:
- judul
- tanggal
- penulis
- label/kategori
- URL artikel
- gambar pertama dari isi posting

Halaman detail membuka URL artikel asli di WebView, sehingga gambar dan isi artikel mengikuti posting di blog.

## Cara membuka
1. Install Android Studio.
2. Open folder `AllnetWorkAndroid`.
3. Tunggu Gradle Sync.
4. Jalankan pada emulator/perangkat Android.
5. Untuk APK: Build > Build APK(s).

## Catatan
Jika Blogger mematikan JSON feed atau template mengubah struktur feed, bagian `fetchPosts()` perlu disesuaikan.


## Versi 2
- Kategori cepat berbentuk chip di beranda.
- Simpan artikel selama aplikasi aktif.
- Bagikan artikel menggunakan menu Android.
- Detail tetap membuka URL artikel asli agar konten dan gambar mengikuti posting blog.
- Struktur beranda mengikuti elemen yang terlihat di allnet-work.web.id: Beranda, kategori, artikel terbaru, dan navigasi website.


## Firebase
Firebase Analytics and Firebase Cloud Messaging are configured using the supplied `google-services.json`. The Firebase Android package is `id.web.allnetwork.news`.


## Audit V6
- Java compile target dan Kotlin JVM target disamakan ke Java 17.
- Firebase Cloud Messaging tetap aktif dengan package `id.web.allnetwork.news`.
- Aplikasi otomatis subscribe ke topic `allnet_news`.
- Android 13+ meminta izin notifikasi saat aplikasi pertama dibuka.
- Ikon notifikasi menggunakan ikon monochrome khusus yang sesuai untuk `setSmallIcon`.
- Notifikasi dapat membuka kembali aplikasi saat diketuk.
- Dependensi `androidx.core:core-ktx` ditambahkan secara eksplisit untuk API notifikasi.
- Tidak menambahkan AdMob tanpa App ID/ad unit ID resmi agar tidak memasukkan ID palsu.
